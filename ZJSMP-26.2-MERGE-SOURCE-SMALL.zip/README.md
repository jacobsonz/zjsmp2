# ZJSMP 26.2 Merge Workspace

Real source/build workspace — not a fake or renamed JAR.

Target: Paper 26.2 / Java 25.

Included: ZJSMP base JAR, UltimateDonutSmp 1.5 reference JAR, PlaceholderAPI 2.12.3, and ProtocolLib ZJSMP 26.2 fork source.

The supplied ZJSMP and UltimateDonutSmp files are compiled binaries, so a complete source-level merge cannot honestly be claimed without the source project. This ZIP preserves the actual inputs and ProtocolLib source instead of pretending a binary rename is a working port.
